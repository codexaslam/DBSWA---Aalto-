const handleRequest = (request) => {
  return new Response(JSON.stringify({ message: "Hello world!" }), {
    headers: { "Content-Type": "application/json" },
  });
};

export default handleRequest;
