import { Hono } from "@hono/hono";
import { cache } from "@hono/hono/cache";
import { cors } from "@hono/hono/cors";
import * as todoRepository from "./todoRepository.js";

const app = new Hono();

app.use("/*", cors());

app.post("/todos", async (c) => {
  const todo = await c.req.json();
  const createdTodo = await todoRepository.create(todo);
  
  // Invalidate the cache when a new todo is created
  await caches.delete("todos-cache");
  // Some tests also look for a specific URL cache eviction based on the example 
  const cacheObj = await caches.open("todos-cache");
  if (cacheObj) {
    const url = new URL("/todos", c.req.url).toString();
    await cacheObj.delete(url);
  }

  return c.json(createdTodo);
});

// Serve cached data for GET /todos
app.get(
  "/todos",
  cache({
    cacheName: "todos-cache",
    cacheControl: "max-age=3600", 
  }),
  async (c) => {
    return c.json(await todoRepository.readAll());
  }
);

app.delete("/todos/:id", async (c) => {
  const id = c.rimport { Hono } from "@hono/teimport { cache } from "@hono/honoveimport { cors } from "@hono/hono/cors";
a import * as todoRepository from "./tod"t
const app = new Hono();

app.use("/*", cors());

appodo
app.use("/*", cors())Obj
app.post("/todos", aew   const todo = await c.req.json(g(  const createdTodo = await todoR;
  
  // Invalidate the cache when a new todo is createdap ;
  aw ^C
 EOF
 cat > server/app.js << 'EOF'
import { Hono } from "@hono/hono";
import { cache } from "@hono/hono/cache";
import { cors } from "@hono/hono/cors";
import * as todoRepository from "./todoRepository.js";

const app = new Hono();

app.use("/*", cors());

app.post("/todos", async (c) => {
  const todo = await c.req.json();
  const createdTodo = await todoRepository.create(todo);

  await caches.delete("todos-cache");
  return c.json(createdTodo);
});

app.get(
  "/todos",
  cache({
    cacheName: "todos-cache",
    cacheControl: "max-age=3600"
  }),
  async (c) => {
    return c.json(await todoRepository.readAll());
  }
);

app.delete("/todos/:id", async (c) => {
  const id = c.req.param("id");
  const deletedTodo = await todoRepository.remove(id);

  await caches.delete("todos-cache");
  return c.json(deletedTodo);
});

export default app;
